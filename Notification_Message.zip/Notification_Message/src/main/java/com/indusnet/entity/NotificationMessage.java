package com.indusnet.entity;

import java.time.LocalDateTime;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@NoArgsConstructor
@AllArgsConstructor
@Data
@Entity
public class NotificationMessage{
	@Id
	private Long id;
	
	private LocalDateTime created_at;
	
	private LocalDateTime updated_at;
	
	private String message;
	
	private String notificationCode;
	
	private Integer trigeredTo;
	
	private Integer status;
	

}
