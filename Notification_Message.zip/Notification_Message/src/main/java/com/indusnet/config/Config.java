package com.indusnet.config;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.bind.annotation.RestController;

import com.indusnet.entity.NotificationMessage;
import com.indusnet.repository.NotificationMessageRepo;

@Configuration
public class Config {
	
	@Autowired  
	private NotificationMessageRepo notificationMessageRepo;
	
	@Bean
	public void saveNotificationMessage() {
		
		List<NotificationMessage>  notificationList = new ArrayList<>();
		
		// Twinkle
		notificationList.add(new NotificationMessage(1L, LocalDateTime.now(),LocalDateTime.now(), "Congratulations! Thank you for registering with UpCapita.", "WHEN_USER_ONBOARDS_INTO_THE_APPLICATION",3,1));
		notificationList.add(new NotificationMessage(2L,LocalDateTime.now() , LocalDateTime.now(), "Hello User! Please complete your account to get more benefits.", "TO_COMPLETE_THE_ACCOUNT_CREATION",2,1));
		notificationList.add(new NotificationMessage(3L,LocalDateTime.now() , LocalDateTime.now(), "Hi [USERNAME], thank you completeing your UpCapita account.", "WHEN_USER_COMPLETES_ACCOUNT_CREATION",3,1));
		notificationList.add(new NotificationMessage(4L,LocalDateTime.now() , LocalDateTime.now(), "Hi [USERNAME], please complete your profile to get matching advisors.", "TO_COMPLETE_THE_PROFILE",2,1));
		notificationList.add(new NotificationMessage(5L,LocalDateTime.now() , LocalDateTime.now(), "Hi [USERNAME], thank you for completeing your profile with us.", "WHEN_CUSTOMER_COMPLETES_THE_PROFILE",2,1));
		notificationList.add(new NotificationMessage(6L,LocalDateTime.now() , LocalDateTime.now(), "Hi [USERNAME], please submit few answers to get the best matching results of advisors.", "TO_SUBMIT_THE_PRE-SEARCH_QUESTION",2,1));
		notificationList.add(new NotificationMessage(7L,LocalDateTime.now() , LocalDateTime.now(), "Hi [USERNAME], thank you for setting up your profile with us.", "WHEN_ADVISOR_COMPLETES_THE_PROFILE",1,1));
		notificationList.add(new NotificationMessage(8L,LocalDateTime.now() , LocalDateTime.now(), "Congratulations [USERNAME]! your deatils have been validated.", "WHEN_ADVISOR_PROFILE'S_HAS_BEEN_VALIDATED_BY_THE_ADMIN",1,1));
		
		//Raja Ram
		notificationList.add(new NotificationMessage(9L,LocalDateTime.now(),LocalDateTime.now(), "Congratulation [USERNAME] your profile details has been validated.", "WHEN_CUSTOMER_FILLS_UP_THE_PRE-SEARCH_QUESTIONS", 2, 1));
		notificationList.add(new NotificationMessage(10L,LocalDateTime.now(),LocalDateTime.now(), "Great [USERNAME] your preferences have been saved.Please continue searching for advisor. ", "WHEN_PROFILE_IS_UPDATED_BY_THE_CUSTOMER", 2, 1));
		notificationList.add(new NotificationMessage(11L,LocalDateTime.now(),LocalDateTime.now(), "Your profile details has been updated.", "WHEN_PROFILE_IS_UPDATED_BY-ADVISOR", 1, 1));
		notificationList.add(new NotificationMessage(12L,LocalDateTime.now(),LocalDateTime.now(), "Your profile details has been updated and submitted for validation.", "WHEN_PROFILE_UPDATES_BY_ADVISOR_HAS_BEEN_VALIDATED_BY_THE ADMIN", 1, 1));
		notificationList.add(new NotificationMessage(13L,LocalDateTime.now(),LocalDateTime.now(), "Congratulation! Your profile changes has been approved."," WHEN_ MEETING_IS_REQUESTED_BY_THE_CUSTOMER_CUSTOMER", 2, 1));
		notificationList.add(new NotificationMessage(14L,LocalDateTime.now(),LocalDateTime.now(), "Your meeting request [ADVISOR] has been scheduled on [TIMESTAMP].", "WHEN_ MEETING_IS_REQUESTED_BY_THE_CUSTOMER_ADVISOR", 1, 1));
		notificationList.add(new NotificationMessage(15L,LocalDateTime.now(),LocalDateTime.now(), "You have a new meeting request from [CUSTOMER]", "WHEN_MEETING_IS_ACCEPTED_BY_THE ADVISOR", 2, 1));
		notificationList.add(new NotificationMessage(16L,LocalDateTime.now(),LocalDateTime.now(), "Your meeting request has been accepted by [ADVISOR].Please pay to continue with the meeting", "WHEN_MEETING_IS_DECLINED_BY_THE_ADVISOR", 2, 1));
		
		// Ranjit
		notificationList.add(new NotificationMessage(17L,LocalDateTime.now(),LocalDateTime.now(),"You meeting request has been rescheduled by [ADVISOR].","WHEN_MEETING_IS_RESCHEDULED_BY_ADVISOR",2,1));
		notificationList.add(new NotificationMessage(18L,LocalDateTime.now(),LocalDateTime.now(),"Your rescheduled preference has been accepted by [CUSTOMER]","WHEN_RESCHEDULED_MEETING_IS_ACCEPTED_BY_CUSTOMER_ADVISOR",1,1));
		notificationList.add(new NotificationMessage(19L,LocalDateTime.now(),LocalDateTime.now(),"Your meeting with [ADVISOR] has been scheduled. Please pay to continue with the meeting.","WHEN_RESCHEDULED_MEETING_IS_ACCEPTED_BY_CUSTOMER_CUSTOMER",2,1));
		notificationList.add(new NotificationMessage(20L,LocalDateTime.now(),LocalDateTime.now(),"You meeting request has been declined by [ADVISOR].","WHEN_RESCHEDULED_MEETING_IS_DECLINED_BY_CUSTOMER",1,1));
		notificationList.add(new NotificationMessage(21L,LocalDateTime.now(),LocalDateTime.now(),"Sorry, [CUSTOMER] is not available on your rescheduled preference. Please check for the new prefered timeslot","WHEN_MEETING_IS_RESCHEDULED_BY_CUSTOMER",2,1));
		notificationList.add(new NotificationMessage(22L,LocalDateTime.now(),LocalDateTime.now(),"Your meeting with [CUSTOMER] has been canceled.","WHEN_RESCHEDULED_MEETING_IS_ACCEPTED_BY_CUSTOMER_ADVISOR",1,1));
		notificationList.add(new NotificationMessage(23L,LocalDateTime.now(),LocalDateTime.now(),"You have canceled your meeting with [ADVISOR]. Please wait for the refund.","WHEN_MEETING_IS_CANCELED_BY_THE_CUSTOMER_CUSTOMER_OUTSIDE(48hrs)",2,1));
		notificationList.add(new NotificationMessage(24L,LocalDateTime.now(),LocalDateTime.now(),"You have canceled your meeting with [ADVISOR]. Please note that no refund will be provided.","WHEN_MEETING_IS_CANCELED_BY_THE_CUSTOMER_CUSTOMER_WITHIN(48hrs)",2,1));
		
		// Sibtain
		notificationList.add(new NotificationMessage(25L,LocalDateTime.now(),LocalDateTime.now(),"Your Meeting has been canceled by the [ADVISOR]. Please wait for the refund","WHEN_MEETING_IS_CANCELED_BY_THE_ADVISOR_CUSTOMER",2,1));
		notificationList.add(new NotificationMessage(26L,LocalDateTime.now(),LocalDateTime.now(),"You have canceled your meeting with [CUSTOMER].","WHEN_MEETING_IS_CANCELED_BY_THE_ADVISOR_ADVISOR",1,1));
		notificationList.add(new NotificationMessage(27L,LocalDateTime.now(),LocalDateTime.now(),"Thank you for making the payment of [AMOUNT] for the meeting with [ADVISOR] on [TIMESTAMP].","WHEN_PAYMENT_IS_DONE_BY_THE_CUSTOMER_CUSTOMER",2,1));
		notificationList.add(new NotificationMessage(28L,LocalDateTime.now(),LocalDateTime.now(),"Please use the OTP [OTP], to start the meeting with [CUSTOMER].","WHEN_PAYMENT_IS_DONE_BY_THE_CUSTOMER_ADVISOR",1,1));
		notificationList.add(new NotificationMessage(29L,LocalDateTime.now(),LocalDateTime.now(),"Meeting has been authorized. Enjoy your meeting with [ADVISOR].","WHEN_OTP_IS_AUTHENTICATED_FOR_STARTING_THE_MEETING",2,1));
		notificationList.add(new NotificationMessage(30L,LocalDateTime.now(),LocalDateTime.now(),"You have a new message from [CUSTOMER].","WHEN_CUSTOMER_SENDS_A_CHAT_MESSAGE_AFTER_THE_CALL_TO_THE_ADVISOR",1,1));
		notificationList.add(new NotificationMessage(31L,LocalDateTime.now(),LocalDateTime.now(),"Please use the OTP [OTP] to end the meeting with [ADVISOR].","WHEN_THE_ADVISOR_ENDS_THE_MEETING",2,1));
		notificationList.add(new NotificationMessage(32L,LocalDateTime.now(),LocalDateTime.now(),"Thank you for attending the meeting with [ADVISOR]. Please share your feedback.","WHEN_THE_MEETING_IS_COMPLETED_CUSTOMER",2,1));
		
		//Aarif
		notificationList.add(new NotificationMessage(33L, LocalDateTime.now(), LocalDateTime.now(), "Thank you for attending the meeting with [ACUSTOMER]", "WHEN_THE_MEETING_IS_COMPLETED_ADVISOR", 1, 1));
		notificationList.add(new NotificationMessage(34L, LocalDateTime.now(), LocalDateTime.now(), "Your support ticket has been submitted.", "WHEN_A_SUPPORT_TICKET_IS_SUBMITTED_BY_THE_USER", 3, 1));
		notificationList.add(new NotificationMessage(35L, LocalDateTime.now(), LocalDateTime.now(), "Please join the call with [ADVISOR] at [TIME]", "BEFORE_15MIN_OF_THE_MEETING_CUSTOMER", 2, 1));
		notificationList.add(new NotificationMessage(36L, LocalDateTime.now(), LocalDateTime.now(), "Please join the call with [CUSTOMER] at [TIME]", "BEFORE_15MIN_OF_THE_MEETING_ADVISOR", 1, 1));
		notificationList.add(new NotificationMessage(37L, LocalDateTime.now(), LocalDateTime.now(), "Attention! There is an upcoming webinar at [TIME]. Please join if you wish to attend it.", "BEFORE_24HRS_FOR_AN_WEBINAR", 3, 1));
		notificationList.add(new NotificationMessage(38L, LocalDateTime.now(), LocalDateTime.now(), "Gentle reminder to keep you posted, that the upcoming webinar is starting in 15mins.", "BEFORE_24MIN_FOR_AN_WEBINAR", 3, 1));
		notificationList.add(new NotificationMessage(39L, LocalDateTime.now(), LocalDateTime.now(), "Please note that the refund has been processed for your canceled meeting with [ADVISOR]. Let us know in case of any discrepency.", "WHEN_THE_REFUND_HAS_BEEN_PROCESSED_FOR_THE_CUSTOMER", 2, 1));
		notificationList.add(new NotificationMessage(40L, LocalDateTime.now(), LocalDateTime.now(), "Hurray! You have received [NO. OF POINTS] as loyalty points.", "WHEN_LOYALTY_POINTS_HAS_BEEN_ALLOTED_TO_THE_CUSTOMER", 2, 1));

		List<NotificationMessage> dataList =   notificationMessageRepo.saveAll(notificationList);
		
		
	}
	
	

}
